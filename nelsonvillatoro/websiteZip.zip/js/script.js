// Initialize AOS library for scroll animations
document.addEventListener("DOMContentLoaded", function() {
  // Initialize AOS animation library
  if (typeof AOS !== 'undefined') {
    AOS.init({
      duration: 1000,
      once: true
    });
  }

  // Initialize GSAP animations only if ScrollTrigger is available
  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
    
    gsap.utils.toArray("section").forEach((section) => {
      gsap.from(section, {
        opacity: 0,
        y: 50,
        duration: 1,
        ease: "power2.out",
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
          toggleActions: "play none none reverse"
        }
      });
    });
  }

  // Only initialize Vue if the #app element exists
  const appElement = document.getElementById('app');
  if (appElement && typeof Vue !== 'undefined') {
    console.log('Initializing Vue app');
    const app = new Vue({
      el: '#app',
      data: {
        blogPosts: [],
        filteredPosts: [],
        categories: [],
        activeTags: [],
        activeCategory: 'all',
        currentPost: null,
        isViewingSinglePost: false,
        isLoading: true,
        form: {
          name: '',
          email: ''
        },
        modalMessage: '',
        modalColor: ''
      },
      mounted() {
        console.log('Vue app mounted');
        this.loadBlogPosts();
        
        // Handle hash navigation
        window.addEventListener('hashchange', this.handleHashChange);
        this.handleHashChange();
      },
      methods: {
        loadBlogPosts() {
          this.isLoading = true;
          console.log('Loading blog posts...');
          // Use a relative path to avoid CORS issues
          axios.get('assets/blog.json')
            .then(response => {
              console.log('Blog posts loaded:', response.data);
              this.blogPosts = response.data.posts || [];
              this.filteredPosts = [...this.blogPosts];
              
              // Extract unique categories
              this.categories = ['all', ...new Set(this.blogPosts.map(post => post.category))];
              
              this.isLoading = false;
              
              // Check if we need to show a specific post based on URL
              this.handleHashChange();
            })
            .catch(error => {
              console.error('Error loading blog posts:', error);
              this.isLoading = false;
            });
        },
        
        handleHashChange() {
          const hash = window.location.hash;
          console.log('Hash changed to:', hash);
          
          try {
            // Handle blog post view
            if (hash.startsWith('#blog/post/')) {
              const slug = hash.replace('#blog/post/', '');
              const post = this.blogPosts.find(p => p.slug === slug);
              
              if (post) {
                this.viewPost(post);
              } else {
                // Invalid post slug, redirect to blog
                window.location.hash = '#blog';
              }
            } 
            // Handle blog category filtering
            else if (hash.startsWith('#blog/category/')) {
              const category = hash.replace('#blog/category/', '');
              this.filterByCategory(category);
            }
            // Handle blog tag filtering
            else if (hash.startsWith('#blog/tag/')) {
              const tag = hash.replace('#blog/tag/', '');
              this.filterByTag(tag);
            }
            // Reset to blog list view if on blog section
            else if (hash === '#blog') {
              this.isViewingSinglePost = false;
              this.currentPost = null;
              this.activeCategory = 'all';
              this.activeTags = [];
              this.filteredPosts = [...this.blogPosts];
            }
            // Handle home view and default case
            else if (hash === '' || hash === '#' || hash === '#home') {
              console.log('Navigating to home section');
              const homeSection = document.getElementById('home');
              if (homeSection) {
                homeSection.scrollIntoView({ behavior: 'smooth' });
              }
            } else {
              // Handle other navigation like portfolio, resume, etc.
              const sectionId = hash.substring(1); // Remove the # from the hash
              const section = document.getElementById(sectionId);
              if (section) {
                console.log('Navigating to section:', sectionId);
                section.scrollIntoView({ behavior: 'smooth' });
              }
            }
          } catch (error) {
            console.error('Error in handleHashChange:', error);
          }
        },
        
        viewPost(post) {
          try {
            this.currentPost = post;
            this.isViewingSinglePost = true;
            
            // Scroll to blog section
            const blogSection = document.getElementById('blog');
            if (blogSection) {
              blogSection.scrollIntoView({ behavior: 'smooth' });
            }
            
            // Update URL without triggering hashchange event
            history.replaceState(null, null, `#blog/post/${post.slug}`);
          } catch (error) {
            console.error('Error in viewPost:', error);
          }
        },
        
        backToBlogList() {
          this.isViewingSinglePost = false;
          this.currentPost = null;
          window.location.hash = '#blog';
        },
        
        filterByCategory(category) {
          this.activeCategory = category;
          this.applyFilters();
          
          // Update URL
          if (category === 'all') {
            window.location.hash = '#blog';
          } else {
            history.replaceState(null, null, `#blog/category/${category}`);
          }
        },
        
        filterByTag(tag) {
          if (this.activeTags.includes(tag)) {
            this.activeTags = this.activeTags.filter(t => t !== tag);
          } else {
            this.activeTags.push(tag);
          }
          this.applyFilters();
          
          // Update URL if only one tag is active
          if (this.activeTags.length === 1) {
            history.replaceState(null, null, `#blog/tag/${this.activeTags[0]}`);
          } else if (this.activeTags.length === 0) {
            window.location.hash = '#blog';
          }
        },
        
        applyFilters() {
          let filtered = [...this.blogPosts];
          
          // Apply category filter
          if (this.activeCategory !== 'all') {
            filtered = filtered.filter(post => post.category === this.activeCategory);
          }
          
          // Apply tags filter
          if (this.activeTags.length > 0) {
            filtered = filtered.filter(post => 
              this.activeTags.every(tag => post.tags.includes(tag))
            );
          }
          
          this.filteredPosts = filtered;
        },
        
        formatDate(dateString) {
          const options = { year: 'numeric', month: 'long', day: 'numeric' };
          return new Date(dateString).toLocaleDateString(undefined, options);
        },
        
        submitForm(event) {
          event.preventDefault();
          if (this.form.name === '' || this.form.email === '') {
            this.showModal("Please fill in all required fields.", "red");
            return;
          }

          // Simple form submission without relying on external services
          this.showModal("Thank you for subscribing! You'll receive updates soon.", "green");
          this.form.name = '';
          this.form.email = '';

          /* Uncomment this when PHP is properly working
          const formData = new FormData();
          formData.append('name', this.form.name);
          formData.append('email', this.form.email);
          formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

          axios.post('subscribe.php', formData)
            .then(response => {
              this.showModal(response.data.message, response.data.status === "success" ? "green" : "red");
              if (response.data.status === "success") {
                this.form.name = '';
                this.form.email = '';
              }
            })
            .catch(error => {
              console.error('Error:', error);
              this.showModal("An error occurred. Please try again.", "red");
            });
          */
        },
        
        showModal(message, color) {
          this.modalMessage = message;
          this.modalColor = color;
          const modal = document.getElementById('subscribe-modal');
          if (modal) {
            modal.style.display = "block";
          }
        }
      }
    });
  } else {
    console.warn('Vue or #app element not available');
  }

  // Close modal when clicking on X or outside the modal
  const modal = document.getElementById('subscribe-modal');
  const closeBtn = document.getElementsByClassName('close')[0];

  if (modal && closeBtn) {
    closeBtn.onclick = function() {
      modal.style.display = "none";
    }
    
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
  }

  // Smooth scrolling for navigation links
  document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const href = this.getAttribute('href');
      const target = document.querySelector(href);
      if (target) {
        console.log('Smooth scrolling to:', href);
        target.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Mobile menu toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('nav ul');
  
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', function() {
      nav.classList.toggle('active');
      menuToggle.classList.toggle('active');
    });
  }
});